PATH=/cygdrive/c/usr/local/mingw/bin:/usr/bin
export PATH
