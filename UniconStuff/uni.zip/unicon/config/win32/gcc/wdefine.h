/*
 * Symbols for iconx/wiconx, but not nticonx
 */

#define MSWindows
#define FAttrib 1
