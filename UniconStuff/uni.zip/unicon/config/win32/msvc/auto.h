/* src/h/auto.h for MS Visual C++ */
/* define's for zlib, jpeg, opengl, etc. */

/* define as 1 if we have Zlib/libz/whatever */
/* #undef HAVE_LIBZ */

/* define as 1 if we have jpeg */
/* #undef HAVE_LIBJPEG */

/* define as 1 if we have opengl */
/* #undef HAVE_LIBGL */

/* define as 1 if we have odbc */
/* #undef HAVE_LIBIODBC */

/* define as 1 if we have getrlimit */
/* #undef HAVE_GETRLIMIT */

/* define as 1 if we have setrlimit */
/* #undef HAVE_SETRLIMIT */

/* define as 1 if we have a timezone variable */
/* #undef HAVE_TIMEZONE */

/* define as 1 if struct tm has a tm_zone field */
/* #undef HAVE_STRUCT_TM_TM_ZONE */

/* define as 1 if tzname exists */
/* #undef HAVE_TZNAME */
