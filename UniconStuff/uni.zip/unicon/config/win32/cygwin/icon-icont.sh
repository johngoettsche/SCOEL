cd src/rtt
make
cd ../runtime
make interp_all
cd ../icont
make
