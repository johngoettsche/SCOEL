#define RootPath "/usr/local"
#define IcontPath "/usr/local/lib/icon/icont"
#define IconxPath "/usr/local/lib/icon/iconx"
