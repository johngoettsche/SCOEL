/*
 * Icon configuration file for PPC running Darwin 1.4 or newer.
 */

#define UNIX 1
#define NEED_UTIME
/* LoadFunc not implemented */

