#define NTConsole 1
