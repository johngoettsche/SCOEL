/* #define HAVE_LIBZ 0 */
/* #define HAVE_LIBJPEG 0 */
#define HAVE_STRING_H 1
#define HAVE_FCNTL_H 1
#define HAVE_RENAME 1
#define HAVE_FSYNC 1
