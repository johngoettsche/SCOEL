/*
 * These are the most common values for system-specific definitions used
 * throughout Icon.  They serve as a start for a port to a new system.
 */

#define DeBug
#define FixedRegions
#define HostStr "unspecified host"
#define NoCoExpr

#define PORT 1
