/*
 * Icon configuration file for BSD/OS
 */

#define UNIX 1
#define LoadFunc
#define SysOpt

#define LinkLibs " -lcompat -lm"
#define COpts "-I/usr/X11R6/include -L/usr/X11R6/lib"
