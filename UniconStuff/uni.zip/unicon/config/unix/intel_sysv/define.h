/*
 * Icon configuration file for the i386 running under System V.
 */

#define UNIX 1

#define SigFncCast

#define COpts "-O"

#define NoIconify
