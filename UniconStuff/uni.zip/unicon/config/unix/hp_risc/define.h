/*
 *  Icon configuration file for HP Precision [RISC] architecture
 */
#define UNIX 1
#define HP 1
#define SysOpt

#define CStateSize 20
#define StackSize 10000
#define UpStack
#define Double
