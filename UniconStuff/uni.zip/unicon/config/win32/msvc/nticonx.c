__declspec(dllimport) iconx_entry(int argc,char ** argv);

main(int argc,char ** argv)
{
   iconx_entry(argc,argv);
}
