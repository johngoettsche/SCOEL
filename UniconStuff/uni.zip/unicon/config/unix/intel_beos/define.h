/*  
 * Icon configuration file for BeOS on Intel
 */

#define UNIX 1			/* not really, but close */
#define NoKeyboardFncs

#define CComp "cc"
#define COpts "-O2"
