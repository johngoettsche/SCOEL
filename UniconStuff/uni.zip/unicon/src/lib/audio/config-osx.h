#define WORDS_BIGENDIAN 1

/* #undef DEBUG */
/* #undef DEBUG_BUFFER */
/* #undef DEBUG_CONFIG */
/* #undef DEBUG_CONTEXT */
/* #undef DEBUG_CONVERT */
/* #undef DEBUG_EXT */
/* #undef DEBUG_LOCK */
/* #undef DEBUG_LOOP */
/* #undef DEBUG_MATH */
/* #undef DEBUG_MAXIMUS */
/* #undef DEBUG_MEM */
/* #undef DEBUG_MIXER */
/* #undef DEBUG_SOURCE */
/* #undef DEBUG_STREAMING */
/* #undef DEBUG_STUB */
/* #undef DEBUG_QUEUE */

/* #undef BOMB */
/* #undef FFT */
#define PIC 1

/* #undef DMALLOC */
/* #undef DMALLOC_FUNC_CHECK */
/* #undef JLIB */

/* #undef PARANOID_LOCKS */
/* #undef EMPTY_LOCKS */

#define USE_POSIXTHREADS 1
#define USE_POSIXMUTEX 1

#define NODLOPEN 1
#define RDYNAMIC "-rdynamic"

#define WORDS_BIGENDIAN 1

#define DARWIN_TARGET 1
#define NULL_SUPPORT 1
#define WAVEOUT_SUPPORT 1
/* #undef SMPEG_SUPPORT */
/* #undef VORBIS_SUPPORT */
/* #undef ALSA_SUPPORT */
/* #undef ARTS_SUPPORT */
/* #undef CAPTURE_SUPPORT */
/* #undef ESD_SUPPORT */
/* #undef IRIS_SUPPORT */
/* #undef SDL_SUPPORT */
/* #undef DSOUND_SUPPORT */
/* #undef SMPEG_SUPPORT */
/* #undef VORBIS_SUPPORT */
/* #undef BROKEN_LIBIO */

/* The number of bytes in a void *.  */
#define SIZEOF_VOID_P 4
