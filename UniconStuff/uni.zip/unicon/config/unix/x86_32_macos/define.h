/*
 * Icon configuration file for PPC running Darwin 1.4 or newer.
 */

#define StackAlign 16
#define UNIX 1
#define NEED_UTIME
#define NamedSemaphores
#define MacOSX
/* LoadFunc not implemented */

#define NoKeyword__Thread 1
