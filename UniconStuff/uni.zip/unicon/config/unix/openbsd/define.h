/*  
 * Icon configuration file for OpenBSD
 */

#define UNIX 1
#define GenericBSD
#define BSD_4_4_LITE    1	/* This is new, for 4.4Lite specific stuff */
#define USE_OLD_TTY

#define LoadFunc
#define SysOpt

#define COpts "-O2 -L/usr/X11R6/lib -I/usr/X11R6/include"
#define NEED_UTIME
