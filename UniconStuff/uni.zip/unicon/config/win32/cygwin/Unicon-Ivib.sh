cd ipl/lib
make
cd ../../uni/unicon
make unicon
cd ../lib
make
cd ../ivib
make ivib
cd ../ide
make
