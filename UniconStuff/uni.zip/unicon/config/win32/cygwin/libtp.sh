cd ../libtp
make -f makefile.wgc libtp.a
cd ../runtime
