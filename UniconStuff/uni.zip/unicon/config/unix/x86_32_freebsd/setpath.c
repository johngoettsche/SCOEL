#include "paths.h"
#include "../Generic/setpath.h"
