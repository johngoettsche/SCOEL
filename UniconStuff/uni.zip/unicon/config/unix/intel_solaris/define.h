/*
 * Icon configuration file for i386 running Solaris 2.x with Sun cc
 */

#define UNIX 1
#define SUN 1

#define SysOpt

#define COpts "-I/usr/openwin/include"

