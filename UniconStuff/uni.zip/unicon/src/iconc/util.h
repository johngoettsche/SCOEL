#ifndef UTIL_H
#define UTIL_H __DATE__" "__TIME__

extern struct code * util_gencodeary(int, ...);
extern char * util_gettreenodetypename(int);
extern int util_getvarflags(int, char *, int);

#endif /* UTIL_H */

