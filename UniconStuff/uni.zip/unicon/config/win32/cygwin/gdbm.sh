cd ../gdbm
make -f makefile.wgc libgdbm.a
cd ../runtime
