/*
 * Icon configuration file for IBM RS/6000 running AIX 4.2 or newer
 */

#define UNIX 1
#define LoadFunc	/* requires 4.2 or newer */
#define SysOpt

#define StackAlign 8
