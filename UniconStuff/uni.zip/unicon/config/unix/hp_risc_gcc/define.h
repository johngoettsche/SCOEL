/*
 *  Icon configuration file for HP Precision [RISC] architecture using gcc
 */
#define UNIX 1
#define SysOpt

#define CStateSize 20
#define StackSize 10000
#define UpStack
#define Double
