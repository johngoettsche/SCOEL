/*
 * This section lists 64-bit specific parameters (if any)
 */

#define MSWIN64

#define IntBits 32
#define WordBits 64
#define StackAlign 16
#define LongLongWord

/*
 *   **************************************************
 */
